package com.nurobots.api.robot;

import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public interface Robot {
    long getId();

    @NotNull UUID getOwnerId();

    @NotNull OfflinePlayer getOwner();

    @Nullable String getOwnerName();

    @NotNull RobotType getType();

    @Nullable String getServerId();

    int getLevel();

    int getMaxLevel();

    boolean isMaxLevel();

    long getExperience();

    long getExperienceToNextLevel();

    int getSkillLevel(@NotNull String skillId);

    @NotNull @Unmodifiable Map<String, Integer> getSkillLevels();

    boolean isPlaced();

    @Nullable Location getLocation();

    @Nullable UUID getEntityId();

    @NotNull RobotStatus getStatus();

    double getEfficiency();

    double getSpeed();

    double getProgress();

    @NotNull Duration getTimeUntilNextCycle();

    long getItemsGenerated();

    @NotNull Instant getCreatedAt();

    @Nullable Instant getLastWorkedAt();

    int getStoredCount();

    int getStorageCapacity();

    boolean isStorageFull();

    @NotNull @Unmodifiable List<ItemStack> getStoredItems();

    boolean isAutoSellEnabled();

    double getRevenueGenerated();

    boolean requiresFuel();

    int getFuel();

    int getMaxFuel();

    boolean hasDurability();

    double getDurability();

    double getMaxDurability();

    boolean isBroken();

    @NotNull @Unmodifiable Set<UUID> getTrusted();

    boolean canAccess(@NotNull UUID playerId);

    @NotNull ItemFilter getFilter();

    @Nullable Component getCustomName();

    @NotNull Component getDisplayName();
}
