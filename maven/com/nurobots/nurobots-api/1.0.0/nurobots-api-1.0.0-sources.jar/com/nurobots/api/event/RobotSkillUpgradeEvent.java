package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import com.nurobots.api.skill.Skill;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RobotSkillUpgradeEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final Skill skill;
    private final int fromLevel;
    private final int toLevel;
    private double cost;
    private boolean cancelled;

    public RobotSkillUpgradeEvent(@NotNull Robot robot,
                                  @Nullable Player player,
                                  @NotNull Skill skill,
                                  int fromLevel,
                                  int toLevel,
                                  double cost) {
        super(robot);
        this.player = player;
        this.skill = skill;
        this.fromLevel = fromLevel;
        this.toLevel = toLevel;
        this.cost = cost;
    }

    public @Nullable Player getPlayer() {
        return player;
    }

    public @NotNull Skill getSkill() {
        return skill;
    }

    public int getFromLevel() {
        return fromLevel;
    }

    public int getToLevel() {
        return toLevel;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = Math.max(0.0D, cost);
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
