package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import com.nurobots.api.robot.RobotStatus;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class RobotStatusChangeEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final RobotStatus previousStatus;
    private final RobotStatus newStatus;
    private boolean cancelled;

    public RobotStatusChangeEvent(@NotNull Robot robot,
                                  @NotNull RobotStatus previousStatus,
                                  @NotNull RobotStatus newStatus) {
        super(robot);
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
    }

    public @NotNull RobotStatus getPreviousStatus() {
        return previousStatus;
    }

    public @NotNull RobotStatus getNewStatus() {
        return newStatus;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
