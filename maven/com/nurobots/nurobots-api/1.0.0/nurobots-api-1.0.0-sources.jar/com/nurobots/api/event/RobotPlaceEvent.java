package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class RobotPlaceEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final Location location;
    private boolean cancelled;

    public RobotPlaceEvent(@NotNull Robot robot, @NotNull Player player, @NotNull Location location) {
        super(robot);
        this.player = player;
        this.location = location;
    }

    public @NotNull Player getPlayer() {
        return player;
    }

    public @NotNull Location getLocation() {
        return location.clone();
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
