package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import com.nurobots.api.skill.WorkModifiers;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class RobotWorkEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final List<ItemStack> output;
    private final WorkModifiers modifiers;
    private long experience;
    private boolean cancelled;

    public RobotWorkEvent(@NotNull Robot robot,
                          @NotNull List<ItemStack> output,
                          @NotNull WorkModifiers modifiers,
                          long experience,
                          boolean async) {
        super(robot, async);
        this.output = output;
        this.modifiers = modifiers;
        this.experience = experience;
    }

    public @NotNull List<ItemStack> getOutput() {
        return output;
    }

    public @NotNull WorkModifiers getModifiers() {
        return modifiers;
    }

    public long getExperience() {
        return experience;
    }

    public void setExperience(long experience) {
        this.experience = Math.max(0L, experience);
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
