package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RobotFuelEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final ItemStack fuelItem;
    private int amount;
    private boolean cancelled;

    public RobotFuelEvent(@NotNull Robot robot,
                          @Nullable Player player,
                          @Nullable ItemStack fuelItem,
                          int amount) {
        super(robot);
        this.player = player;
        this.fuelItem = fuelItem;
        this.amount = amount;
    }

    public @Nullable Player getPlayer() {
        return player;
    }

    public @Nullable ItemStack getFuelItem() {
        return fuelItem == null ? null : fuelItem.clone();
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = Math.max(0, amount);
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
