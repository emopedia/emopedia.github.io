package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class RobotAutoSellEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final List<ItemStack> items;
    private double revenue;
    private boolean cancelled;

    public RobotAutoSellEvent(@NotNull Robot robot, @NotNull List<ItemStack> items, double revenue) {
        super(robot);
        this.items = items;
        this.revenue = revenue;
    }

    public @NotNull List<ItemStack> getItems() {
        return items;
    }

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = Math.max(0.0D, revenue);
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
