package com.nurobots.api.skill;

import org.jetbrains.annotations.NotNull;

public interface SkillEffect {
    @NotNull String getId();

    @NotNull String getDescription();

    void apply(@NotNull SkillContext context);
}
