package com.nurobots.api.robot;

public enum RobotStatus {
    IDLE,

    WORKING,

    PAUSED,

    BROKEN,

    STORAGE_FULL,

    OUT_OF_FUEL,

    BLOCKED,

    STORED;

    public boolean canWork() {
        return this == IDLE || this == WORKING;
    }

    public boolean needsAttention() {
        return this == BROKEN || this == STORAGE_FULL || this == OUT_OF_FUEL || this == BLOCKED;
    }
}
