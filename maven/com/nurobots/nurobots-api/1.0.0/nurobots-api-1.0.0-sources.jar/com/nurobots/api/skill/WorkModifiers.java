package com.nurobots.api.skill;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Set;

public interface WorkModifiers {
    double getYieldMultiplier();

    void multiplyYield(double factor);

    double getSpeedMultiplier();

    void multiplySpeed(double factor);

    double getEfficiencyMultiplier();

    void multiplyEfficiency(double factor);

    double getDoubleChance();

    void addDoubleChance(double chance);

    double getExperienceMultiplier();

    void multiplyExperience(double factor);

    int getFortuneLevel();

    void addFortuneLevel(int levels);

    boolean isSilkTouch();

    void setSilkTouch(boolean silkTouch);

    boolean isAutoSmelt();

    void setAutoSmelt(boolean autoSmelt);

    boolean isReplant();

    void setReplant(boolean replant);

    double getFuelUseMultiplier();

    void multiplyFuelUse(double factor);

    double getDurabilityUseMultiplier();

    void multiplyDurabilityUse(double factor);

    double getSellPriceMultiplier();

    void multiplySellPrice(double factor);

    int getBonusRadius();

    void addBonusRadius(int blocks);

    int getBonusBlocksPerCycle();

    void addBonusBlocksPerCycle(int blocks);

    @NotNull List<ItemStack> getBonusDrops();

    @NotNull Set<Material> getExtraTargets();

    double getCustom(@NotNull String key, double fallback);

    void setCustom(@NotNull String key, double value);
}
