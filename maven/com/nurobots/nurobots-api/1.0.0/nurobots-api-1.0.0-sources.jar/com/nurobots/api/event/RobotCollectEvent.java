package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class RobotCollectEvent extends RobotEvent implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final List<ItemStack> items;
    private boolean cancelled;

    public RobotCollectEvent(@NotNull Robot robot, @NotNull Player player, @NotNull List<ItemStack> items) {
        super(robot);
        this.player = player;
        this.items = items;
    }

    public @NotNull Player getPlayer() {
        return player;
    }

    public @NotNull List<ItemStack> getItems() {
        return items;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
