package com.nurobots.api.skill;

import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.util.Collection;

public interface SkillEffectRegistry {
    void register(@NotNull Plugin plugin, @NotNull SkillEffect effect);

    boolean unregister(@NotNull String effectId);

    int unregisterAll(@NotNull Plugin plugin);

    @Nullable SkillEffect get(@NotNull String effectId);

    boolean isRegistered(@NotNull String effectId);

    @NotNull @Unmodifiable Collection<SkillEffect> getEffects();
}
