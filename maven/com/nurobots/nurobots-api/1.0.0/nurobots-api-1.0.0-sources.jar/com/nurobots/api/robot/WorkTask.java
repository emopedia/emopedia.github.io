package com.nurobots.api.robot;

public enum WorkTask {
    MINE,

    FARM,

    CHOP,

    FISH,

    HUNT,

    RANCH,

    COLLECT,

    NONE
}
