package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class RobotBreakdownEvent extends RobotEvent {
    private static final HandlerList HANDLERS = new HandlerList();

    public RobotBreakdownEvent(@NotNull Robot robot) {
        super(robot);
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
