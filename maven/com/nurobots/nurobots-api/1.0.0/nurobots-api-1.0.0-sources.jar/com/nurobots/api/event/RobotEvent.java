package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.event.Event;
import org.jetbrains.annotations.NotNull;

public abstract class RobotEvent extends Event {
    private final Robot robot;

    protected RobotEvent(@NotNull Robot robot) {
        this.robot = robot;
    }

    protected RobotEvent(@NotNull Robot robot, boolean async) {
        super(async);
        this.robot = robot;
    }

    public @NotNull Robot getRobot() {
        return robot;
    }
}
