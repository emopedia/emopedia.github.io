package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class RobotLevelUpEvent extends RobotEvent {
    private static final HandlerList HANDLERS = new HandlerList();

    private final int fromLevel;
    private final int toLevel;

    public RobotLevelUpEvent(@NotNull Robot robot, int fromLevel, int toLevel) {
        super(robot);
        this.fromLevel = fromLevel;
        this.toLevel = toLevel;
    }

    public int getFromLevel() {
        return fromLevel;
    }

    public int getToLevel() {
        return toLevel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
