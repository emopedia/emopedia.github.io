package com.nurobots.api;

import com.nurobots.api.robot.Robot;
import com.nurobots.api.robot.RobotType;
import com.nurobots.api.skill.Skill;
import com.nurobots.api.skill.SkillEffectRegistry;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface NuRobotsAPI {
    @NotNull String getVersion();

    @NotNull Optional<Robot> getRobot(long id);

    @NotNull @Unmodifiable Collection<Robot> getRobots(@NotNull UUID ownerId);

    @NotNull @Unmodifiable Collection<Robot> getAllRobots();

    @NotNull Optional<Robot> getRobotAt(@NotNull Location location);

    @NotNull @Unmodifiable Collection<Robot> getRobotsNear(@NotNull Location centre, double radius);

    int countPlacedRobots(@NotNull UUID ownerId);

    int countPlacedRobots(@NotNull UUID ownerId, @NotNull String typeId);

    int getRobotLimit(@NotNull OfflinePlayer player);

    int getTotalRobotCount();

    int getActiveRobotCount();

    int getRobotOwnerCount();

    int getActiveTypeCount();

    @NotNull Optional<RobotType> getRobotType(@NotNull String id);

    @NotNull @Unmodifiable Collection<RobotType> getRobotTypes();

    @NotNull Optional<Skill> getSkill(@NotNull String id);

    @NotNull @Unmodifiable Collection<Skill> getSkills();

    @NotNull SkillEffectRegistry getSkillEffectRegistry();

    boolean isRobotItem(@Nullable ItemStack item);

    @NotNull Optional<RobotType> getRobotItemType(@Nullable ItemStack item);

    int getRobotItemLevel(@Nullable ItemStack item);

    @NotNull ItemStack createRobotItem(@NotNull RobotType type, int level);

    @NotNull CompletableFuture<Robot> createRobot(@NotNull UUID ownerId, @NotNull RobotType type, int level);

    boolean removeRobot(long id);

    boolean setLevel(long id, int level);

    boolean setSkillLevel(long id, @NotNull String skillId, int level);

    boolean addFuel(long id, int amount);

    boolean repair(long id);

    boolean setPaused(long id, boolean paused);

    boolean setAutoSell(long id, boolean enabled);

    @NotNull List<ItemStack> emptyStorage(long id);

    boolean trust(long id, @NotNull UUID playerId);

    boolean untrust(long id, @NotNull UUID playerId);

    @NotNull CompletableFuture<Void> saveAll();
}
