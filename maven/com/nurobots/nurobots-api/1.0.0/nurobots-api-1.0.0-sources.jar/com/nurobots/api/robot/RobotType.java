package com.nurobots.api.robot;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.time.Duration;
import java.util.Collection;
import java.util.List;

public interface RobotType {
    @NotNull String getId();

    @NotNull Component getDisplayName();

    @NotNull @Unmodifiable List<Component> getDescription();

    @NotNull Material getMaterial();

    @Nullable String getHeadTexture();

    @Nullable String getPermission();

    int getMaxLevel();

    @NotNull LevelData getLevel(int level);

    @NotNull WorkMode getWorkMode();

    @NotNull WorkTask getWorkTask();

    @NotNull Duration getCycleTime();

    @NotNull @Unmodifiable Collection<String> getAllowedSkills();

    boolean requiresFuel();

    boolean hasDurability();

    @Nullable String getModelEngineId();

    @Nullable String getMythicMobId();

    @Nullable String getCustomItemId();

    @NotNull ItemStack createItem(int level);

    interface LevelData {
        int getLevel();

        double getCost();

        double getUpgradeCost();

        double getSpeed();

        double getEfficiency();

        int getStorageCapacity();

        int getMaxFuel();

        double getMaxDurability();

        long getExperienceRequired();
    }
}
