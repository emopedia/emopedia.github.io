package com.nurobots.api.robot;

public enum WorkMode {
    VIRTUAL,

    PHYSICAL
}
