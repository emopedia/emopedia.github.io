package com.nurobots.api;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class NuRobotsProvider {
    private static NuRobotsAPI instance;

    private NuRobotsProvider() {
        throw new AssertionError("NuRobotsProvider is a static holder and must not be instantiated.");
    }

    public static @NotNull NuRobotsAPI get() {
        NuRobotsAPI api = instance;
        if (api == null) {
            throw new IllegalStateException(
                    "The NuRobots API is not available yet. NuRobots is either not installed, "
                            + "has not finished enabling, or failed to start. Declare NuRobots as a "
                            + "dependency with 'load: BEFORE' in your paper-plugin.yml, or check "
                            + "NuRobotsProvider.isAvailable() before calling get().");
        }
        return api;
    }

    public static boolean isAvailable() {
        return instance != null;
    }

    @ApiStatus.Internal
    public static void register(@Nullable NuRobotsAPI api) {
        if (api != null && instance != null && instance != api) {
            throw new IllegalStateException(
                    "The NuRobots API is already registered. Another plugin appears to be "
                            + "attempting to replace it, which is not supported.");
        }
        instance = api;
    }
}
