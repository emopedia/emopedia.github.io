package com.nurobots.api.skill;

import com.nurobots.api.robot.Robot;
import org.jetbrains.annotations.NotNull;

public interface SkillContext {
    @NotNull Robot getRobot();

    @NotNull Skill getSkill();

    int getLevel();

    double getMultiplier();

    @NotNull WorkModifiers getModifiers();
}
