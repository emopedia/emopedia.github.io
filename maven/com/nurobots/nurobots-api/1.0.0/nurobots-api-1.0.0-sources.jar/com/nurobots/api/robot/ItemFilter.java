package com.nurobots.api.robot;

import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Unmodifiable;

import java.util.Set;

public interface ItemFilter {
    enum Mode {
        DISABLED,

        WHITELIST,

        BLACKLIST
    }

    @NotNull Mode getMode();

    @NotNull @Unmodifiable Set<String> getEntries();

    boolean test(@NotNull ItemStack item);

    boolean isPassthrough();
}
