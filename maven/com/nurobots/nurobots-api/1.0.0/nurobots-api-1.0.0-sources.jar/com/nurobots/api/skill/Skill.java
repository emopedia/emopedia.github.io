package com.nurobots.api.skill;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.util.List;

public interface Skill {
    @NotNull String getId();

    @NotNull Component getDisplayName();

    @NotNull @Unmodifiable List<Component> getDescription();

    @NotNull Material getIcon();

    int getMaxLevel();

    double getCost(int level);

    double getMultiplier(int level);

    @NotNull String getEffectId();

    @Nullable SkillEffect getEffect();

    @Nullable String getPermission();

    int getRequiredRobotLevel();
}
