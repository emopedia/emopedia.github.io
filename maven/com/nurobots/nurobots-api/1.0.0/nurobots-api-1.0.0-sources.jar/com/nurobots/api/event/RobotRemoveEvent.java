package com.nurobots.api.event;

import com.nurobots.api.robot.Robot;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RobotRemoveEvent extends RobotEvent implements Cancellable {
    public enum Cause {
        PICKUP,

        ADMIN,

        RESET,

        WORLD_REMOVED,

        PLUGIN
    }

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final Cause cause;
    private boolean refundItem = true;
    private boolean cancelled;

    public RobotRemoveEvent(@NotNull Robot robot, @Nullable Player player, @NotNull Cause cause) {
        super(robot);
        this.player = player;
        this.cause = cause;
    }

    public @Nullable Player getPlayer() {
        return player;
    }

    public @NotNull Cause getCause() {
        return cause;
    }

    public boolean isRefundItem() {
        return refundItem;
    }

    public void setRefundItem(boolean refundItem) {
        this.refundItem = refundItem;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
